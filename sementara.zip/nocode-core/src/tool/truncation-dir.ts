import path from "path"
import { Global } from "@nocode-ai-ai/core/global"

export const TRUNCATION_DIR = path.join(Global.Path.data, "tool-output")
